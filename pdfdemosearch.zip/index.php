<?php 
include('PdfToText.phpclass'); 
////////////
$files = scandir('files/');
$myfiles = array();
$string = "create";
 //$string = "/^.*$string.*\$/mi"
foreach($files as $file) {
if($file!='.' && $file!='..') 
{
	$ext = pathinfo($file, PATHINFO_EXTENSION);
	if($ext=='pdf')
	{
		$pdf = new PdfToText('files/'.$file);
		
		$data = $pdf->Text;
		if(stripos($data,$string)!==false){
			echo $string;
			$myfiles[] = $file;
		} else {
		echo "failed";
      }
	}
	
	if($ext=='txt')
	{
		$searchFile = file_get_contents('files/'.$file);
		if (preg_match("#(.{100}$string.{100})#i", $searchFile)) {
			echo 'true';
			$myfiles[] = $file;
			 
		} else {
			echo 'false';
		}
		
	}
	
	if($ext=='html')
	{
		 
		$searchFile = file_get_contents('files/'.$file);
		if (preg_match("#(.{100}$string.{100})#i", $searchFile)) {
			echo 'true';
			$myfiles[] = $file;
			 
		} else {
			echo 'false';
		}
		
	}
}


}
print_r($myfiles);
?>